import streamlit as st
from PIL import Image
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import plotly.express as px
from streamlit_option_menu import option_menu
from sklearn.preprocessing import MinMaxScaler
import streamlit_antd_components as sac
import pickle

data = pd.read_csv('framingham.csv')

data['education'] = data['education'].astype('object')

categorical_features = [value for value in data.columns if data[value].dtype == 'object']
numerical_features = [value for value in data.columns if data[value].dtype != 'object']

st.sidebar.markdown('# Side Panel')
st.sidebar.markdown('''
Use this panel to navigate through different sections of the project, from problem motivation to EDA, visualization, and model prediction for the risk of coronary heart disease.
''')

with st.sidebar:
    selected = sac.menu([
        sac.MenuItem('Home', icon='house-fill'),
        sac.MenuItem('About', icon='question-square'),
        sac.MenuItem('Analysis', icon='file-code', children=[
            sac.MenuItem('EDA', icon='file-bar-graph'),
            sac.MenuItem('Visualization', icon='file-bar-graph')
        ]),
        sac.MenuItem('Prediction', icon='file-bar-graph')
    ])

if selected == "Home":
    import streamlit as st

    # Add custom CSS to increase the font size and center the title
    st.markdown(
        """
        <style>
        .title {
            font-size: 48px; /* Adjust the font size as needed */
            text-align: center; /* Center align the title */
            font-weight: bold; /* Make the title bold */
            width: 100%; /* Make sure the title spans the entire width */
        }
        </style>
        """,
        unsafe_allow_html=True
    )

    # Display the title using the custom CSS class
    st.markdown("<h1 class='title'>Analysis & Prediction of Coronory Heart Disease using 𝘍𝘳𝘢𝘮𝘪𝘯𝘨𝘩𝘢𝘮 Dataset</h1>", unsafe_allow_html=True)

    # st.title(
    #     "𝘈𝘯𝘢𝘭𝘺𝘴𝘪𝘴 & 𝘗𝘳𝘦𝘥𝘪𝘤𝘵𝘪𝘰𝘯 𝘰𝘧 𝘊𝘰𝘳𝘰𝘯𝘢𝘳𝘺 𝘏𝘦𝘢𝘳𝘵 𝘋𝘪𝘴𝘦𝘢𝘴𝘦 𝘜𝘴𝘪𝘯𝘨 𝘍𝘳𝘢𝘮𝘪𝘯𝘨𝘩𝘢𝘮 𝘋𝘢𝘵𝘢𝘴𝘦𝘵")
    st.image('images/chd_img.jpg', use_column_width=True)
    # img = Image.open('C:/Users/allap/OneDrive/Desktop/chd_project/images/img1.jpg')
    # left_co, cent_co, last_co = st.columns(3)
    # with cent_co:
    #     st.image(
    #         'https://www.sgu.edu/blog/medical/wp-content/uploads/sites/2/2018/02/What-Is-Heart-Disease_-Cardiovascular-Health-Problems-Explained.gif',
    #         width=400)
    st.title('HOME PAGE')
    st.markdown(
        "**The Coronary Heart Disease (CHD)** project is an initiative aimed at leveraging **data analysis** and" 
        "**machine learning** techniques to study the risk factors associated with CHD and develop predictive "
        "models for early detection and intervention utilizing, the **Framingham Heart Study dataset**. By leveraging data visualization techniques and machine "
        "learning algorithms, we aim to better understand the factors contributing to CHD and develop "
        "**predictive models** to identify individuals at risk.")
    st.markdown(
        "𝗧𝗼 𝗲𝘅𝗽𝗹𝗼𝗿𝗲 𝗺𝗼𝗿𝗲 𝗶𝗻𝘀𝗶𝗴𝗵𝘁𝘀, 𝗰𝗹𝗶𝗰𝗸 𝗼𝗻 𝘁𝗵𝗲 𝘀𝗶𝗱𝗲𝗯𝗮𝗿 𝗺𝗲𝗻𝘂 𝗼𝗿 𝗻𝗮𝘃𝗶𝗴𝗮𝘁𝗲 𝘁𝗼 𝗱𝗶𝗳𝗳𝗲𝗿𝗲𝗻𝘁 𝘁𝗮𝗯𝘀.")
    st.subheader("☟ Quick Glance of the Dataset ")
    # showing entire raw dataset
    if st.checkbox("Preview Dataset"):
        if st.button("Head"):
            st.write(data.head())
        elif st.button("Tail"):
            st.write(data.tail())
        else:
            st.write(data.head(2))

if selected == "About":
    st.title("ABOUT Dataset")
    st.header("What is Coronary Heart Disease?")
    st.markdown(
        "**Coronary Heart Disease (CHD)** is a leading cause of death globally, characterized by the narrowing or"
        "blockage of the coronary arteries due to the buildup of plaque. This restricts blood flow to the "
        "heart, leading to various cardiovascular complications, including **heart attacks**.Millions of people are impacted by "
        "CHD, making it a **serious public health issue**. Most heart diseases are highly preventable and simple "
        "lifestyle modifications(such as reducing tobacco use, eating healthily, obesity and exercising) "
        "coupled with early treatment greatly improve their prognoses.")
    st.header("Motivation")
    st.markdown('Although life expectancy and survival rates in the United States have improved dramatically over the '
                'past century and US is among the wealthiest nations in the world, but it is far from the healthiest.'
                'Americans live shorter lives and experience more injuries and illnesses than people in other '
                'high-income countries. According to **National Library of Medicine**, the United States fares worse in the Heart Disease health domains when compared with the average for peer countries')
    # images_path = ['images/graph2.PNG', 'images/graph1.PNG']
    # List to store opened images
    # images = []
    # Open each image and append it to the list
    # for path in images_path:
    #     image = Image.open(path)
    #     images.append(image)
    st.image('images/graph2.PNG', use_column_width=True,
             caption='Graph depicts that Cardiovascular disease is one of the prominent and leading cause of deaths in USA')
    # st.image(['https://i.pinimg.com/originals/e5/a5/f1/e5a5f196b9240b52f161a3270ed3181f.gif'], width=350)
    st.header("DATA")
    st.image(['https://sites.bu.edu/nutritionalepilab/files/2017/05/framinghampicpurple.jpg'])
    st.markdown('The **Framingham Cardiovascular Disease (CVD)** dataset, originating from the [Framingham Heart '
                'Study](https://www.framinghamheartstudy.org/) initiated in 1948, is a rich resource for understanding cardiovascular health and risk factors.'
                'The dataset comprises a wide array of health-related data collected from participants over several '
                'decades which Includes diverse variables such as **demographic information, medical history, '
                'lifestyle factors (e.g., smoking habits, physical activity), clinical measurements (e.g., '
                'blood pressure, cholesterol levels), and disease incidence**.')
    st.markdown(
        'The Framingham heart disease dataset includes over **4,240 records, 16 columns and 15 attributes**. The'
        ' goal of the dataset is to predict whether the patient has 10-year risk of future (CHD) coronary '
        'heart disease.The dataset used in this project is taken from **[Kaggle - Click to access the Dataset]('
        'https://www.kaggle.com/datasets/aasheesh200/framingham-heart-study-dataset)**')
    st.header('METHODOLOGIES')
    st.markdown('**Exploratory Data Analysis (EDA)**: We begin by conducting EDA to understand the structure and '
                'distribution of the data, identify missing values, and explore relationships between variables.')
    st.markdown(
        '**Data Cleaning & Preprocessing**: Various Preprocessing steps are performed ensuring that dataset is ready for analysis and modeling, improving the accuracy and reliability of the results.')
    st.markdown(
        '**ML Models Training**: Various machine learning algorithms are employed, to develop predictive models for CHD risk assessment.')
    st.markdown("**Models Evaluation & Selection**: The performance of the models is evaluated using metrics such as "
                "accuracy, precision, recall, and area under the ROC curve (AUC). Then, the best model is used for "
                "the prediction based on the users input.")

    # st.markdown("![Alt Text](https://i.pinimg.com/originals/e5/a5/f1/e5a5f196b9240b52f161a3270ed3181f.gif)")


# preprocessing of the dataset

# st.title('Preprocessing, Exploration and Viz of the Dataset')
# st.sidebar.subheader('Quick Explore')
# st.markdown("Tick the box on the side panel to explore more about this section")
def get_numerical_feature_type(data):
    discrete_features = []
    continuous_features = []

    for val in numerical_features:
        if len(data[val].unique()) < 10:
            discrete_features.append(val)
        else:
            continuous_features.append(val)

    return discrete_features, continuous_features


if selected == "EDA":
    st.title('Exploratory Data Analysis')
    st.subheader('Structure of the Dataset')
    data_dim = st.radio("What Dimensions Do you want?", ("Number of Rows", "Number of Columns", "Total shape"))
    if data_dim == "Number of Rows":
        st.text(f"Number of Rows in the DataFrame: {data.shape[0]}")
    elif data_dim == "Number of Columns":
        st.text(f"Number of Columns in the DataFrame: {data.shape[1]}")
    else:
        st.text(f"Shape of the DataFrame: {data.shape}")
    st.markdown("---")

    # summary of the dataset
    if st.subheader("Summary of the Dataset"):
        st.write(data.describe())
    st.markdown("---")

    # info about the dataset

    # st.subheader("Distribution of the Dataset")
    # st.write(data.info())
    # st.markdown("---")

    # columns of the dataset as list
    if st.subheader("Columns of the Dataset"):
        all_columns = data.columns.to_list()
        st.write(all_columns)
    st.markdown("---")

    # feature combination
    if st.subheader('**Feature Combination**'):
        st.markdown('Combining the attributes **Systolic and Diastolic** to the category **Mean Arterial Pressure** ('
                    'MAP)which is average arterial pressure throughout one cardiac cycle')
        data['MAP'] = ((2 * data['diastolic_BP']) + data['systolic_BP']) / 3
        data.drop(['systolic_BP', 'diastolic_BP'], axis=1, inplace=True)
        st.write(data.head())
    st.markdown("---")

    # feature analysis
    if st.subheader("**Feature types**"):
        numerical_features = [value for value in data.columns if data[value].dtype != 'object']
        categorical_features = [value for value in data.columns if data[value].dtype == 'object']
        st.markdown(f'<p style="font-size: 18px; font-weight: bold;"> Numerical features Count: {len(numerical_features)}</p>', unsafe_allow_html=True)
        st.write(f'They are: {numerical_features}')
        st.markdown(f'<p style="font-size: 18px; font-weight: bold;"> Categorical features Count: {len(categorical_features)}</p>', unsafe_allow_html=True)
        st.write(f'They are: {categorical_features}')
        st.write('--' * 45)

    # Print categorical features analysis
    # if st.subheader("Categorical Feature Distribution Summary"):
    #     for col in categorical_features:
    #         st.write(f'{col.capitalize()}:')
    #         st.write(100 * data[col].value_counts(normalize=True))
    #         st.write('--' * 45)

    # calculating and printing null values percentage of the dataset
    if st.title("Handling Null Values"):
        null_value_count = data.isnull().sum()
        total_percentage_null = null_value_count.sum() / len(data)
        st.write('Percentage of missing values in the DataFrame: {:.3%}'.format(total_percentage_null))

    if st.subheader("Percentage of Missing Data per Category"):
        total = data.isnull().sum().sort_values(ascending=False)
        percent_total = (data.isnull().sum() / data.shape[0] * 100).sort_values(ascending=False)
        missing = pd.concat([total, percent_total], axis=1, keys=["Total", "Percentage"])
        missing_data = missing[missing['Total'] > 0]
        st.write(missing_data)
        if st.subheader("Null Values Percentage Plot"):
            plt.figure(figsize=(10, 5))
            sns.barplot(data=missing_data, x=missing_data.index, y=missing_data.Percentage)
            plt.xlabel('Features')
            plt.xticks(rotation=90)
            plt.ylabel('Null value percentage')
            st.set_option('deprecation.showPyplotGlobalUse', False)
            st.pyplot()

    # filling missing values
    if st.subheader("Filling Missing Values"):
        st.markdown(
            '● Filling Null values in Glucose,BPMeds,totalChol,cigarettes_PerDay,BMI with the mean value of the respective column values.')
        columns = ['glucose', 'total_cholestrol', 'cigarettes_per_day', 'BMI']
        for col in columns:
            data[col].fillna(data[col].mean(), inplace=True)
            data['BP_medication'].fillna(data['BP_medication'].mode()[0], inplace=True)
            data.dropna(inplace=True)
        st.markdown('Data frame after handling null values')
        st.write(data.sample(5))

    # univariate analysis on numerical features
    st.title('Univariate Analysis')
    st.markdown(
        '• Univariate Analysis is analysis of a particular single variable in the dataframe to check the distribution of the value')
    st.markdown('## Numerical Features')
    st.markdown('• Displaying first few rows of the numerical features')
    st.write(data[numerical_features].head())
    # Plotting
    plt.figure(figsize=(16, 10))
    plt.suptitle('Univariate Analysis of Numerical Features', fontsize=20, fontweight='bold')
    # Creating a density plot using kdeplot() function from the seaborn library
    for val in range(0, len(numerical_features)):
        plt.subplot(3, 3, val + 1)
        sns.kdeplot(x=data[numerical_features[val]], color='orangered')
        plt.xlabel(numerical_features[val])
        plt.tight_layout()
    st.pyplot(plt)
    st.markdown('''
    **Insights**
    - **`glucose`:** The distribution looks skewed, possibly due to outliers.
    - **`cigarettes_per_day`, `total_cholesterol`, `MAP`, `BMI`:** These attributes are skewed towards the right.
    - **`age`:** The distribution appears to be balanced.
    - **`heart_rate`:** The distribution is slightly skewed towards the right.
    ''')


    # univariate analysis on categorical features
    st.markdown('## Categorical Features')
    st.markdown('• Displaying first few rows of the categorical features')
    st.write(data[categorical_features].head())
    # plotting
    plt.figure(figsize=(16, 10))
    plt.suptitle('Univariate Analysis of Categorical Features', fontsize=20, fontweight='bold')
    # creating subplots of countplots for each categorical feature
    for val in range(0, len(categorical_features)):
        plt.subplot(3, 3, val + 1)
        sns.countplot(x=data[categorical_features[val]], color='sandybrown')
        plt.xlabel(categorical_features[val])
        plt.tight_layout()
    st.pyplot(plt)
    st.markdown('''
    **Insights**
    - **`sex` and `currentSmoker`:** These attributes have data that is equally distributed.
    - **`education`:** Approximately 70% of the values fall into categories 1 and 2, with the rest belonging to categories 3 and 4.
    - **`BP_medication`, `prevalentStroke`, `prevalentHyp`, `diabetes`, and `risk_of_CHD`:** These attributes have one dominant category ("No"), which will need to be addressed in later analysis.
    - **Target Variable `Risk for CHD`:** This variable is imbalanced, which may cause issues during model training. This will be addressed in further analysis using imbalanced data handling techniques.
    ''')

    st.markdown("---")

    # creating a function to categorizes numerical features into discrete or continuous types and prints their counts
    # and names
    st.title('**Multivariate Analysis**')
    st.markdown('•  Analysis of more than 1 variable is called as multivariate analysis.')
    discrete_features, continuous_features = get_numerical_feature_type(data)
    st.write("Number of Discrete Features:", len(discrete_features))
    st.write(f"They are: {discrete_features}")
    st.write("Number of Continuous Features:",len(continuous_features))
    st.write(f"They are: {continuous_features}")

    from scipy.stats import chi2_contingency
    test_result = []
    #Iterating through the categorical features
    for value in categorical_features:
        if chi2_contingency(pd.crosstab(data['risk_of_CHD'], data[value]))[1] < 0.05:
            test_result.append('Reject Null Hypothesis')
        else:
            test_result.append('Fail to Reject Null Hypothesis')
    multicollinearity_test = pd.DataFrame(data=[categorical_features, test_result]).T
    multicollinearity_test.columns = ['Column', 'Result']
    st.subheader('**multicollinearity_test for numerical features using chi_square test**')
    st.write(multicollinearity_test)
    st.markdown('Here we can observe that most of the features are rejecting the null hypothesis only one feature is not rejecting the null hypothesis\
                we can check that by adding to the model and by dropping the currentSmoker feature and check for the performance of the model')

    # load statmodels functions
    from statsmodels.stats.outliers_influence import variance_inflation_factor
    from statsmodels.tools.tools import add_constant

    # compute the vif for all given features
    def compute_vif(considered_features):

        X = data[considered_features]
        # the calculation of variance inflation requires a constant
        X['intercept'] = 1

        # create dataframe to store vif values
        vif = pd.DataFrame()
        vif["Variable"] = X.columns
        vif["VIF"] = [variance_inflation_factor(X.values, i) for i in range(X.shape[1])]
        vif = vif[vif['Variable']!='intercept']
        return vif
    considered_features = ['age', 'cigarettes_per_day', 'total_cholestrol', 'BMI', 'heart_rate', 'glucose', 'MAP']
    # compute vif
    categorical_multicollinearity = compute_vif(considered_features).sort_values('VIF', ascending=False)
    st.subheader('**Multicollinearity test for Categorical Features using VIF values**')
    st.write(categorical_multicollinearity)
    st.markdown('Her we can observe that all the features are having VIF values that is less than 5 which is a god sign which tells us that there is no serios multicollinearity among the features')

    st.markdown("---")
    # outliers
    # before outliers removal

    st.title('Outliers')
    st.markdown('### Box plot of Numerical Features before Outlier Removal:')
    fig, axes = plt.subplots(nrows=len(numerical_features), figsize=(6, 12))

    # Plot each numerical column as a boxplot
    color = 'Set2'
    for i, col in enumerate(numerical_features):
        sns.boxplot(data=data, x=col, ax=axes[i], palette=color)
        axes[i].set_title(f'Box Plot of {col}')

    plt.tight_layout()

    # Display the plot
    st.pyplot(fig)

    # outlier removal
    numerical_cols = ['age', 'cigarettes_per_day', 'total_cholestrol', 'BMI', 'heart_rate', 'glucose', 'MAP']
    for column in numerical_cols:
        Q1 = data[column].quantile(0.25)
        Q3 = data[column].quantile(0.75)
        IQR = Q3 - Q1
        lower_bound = Q1 - 1.5 * IQR
        upper_bound = Q3 + 1.5 * IQR
        data = data[(data[column] >= lower_bound) & (data[column] <= upper_bound)]
    # Displaying the number of rows after outlier removal
    st.write(f'<span style="font-size: 20px;">Number of rows after outlier removal: {data.shape[0]}</span>', unsafe_allow_html=True)
    st.markdown('### Box plot of Numerical Features after Outlier Removal:')
    # Plotting
    fig, axes = plt.subplots(nrows=len(numerical_features), figsize=(6, 12))

    # Plot each numerical column as a boxplot
    color = 'Set2'
    for i, col in enumerate(numerical_features):
        sns.boxplot(data=data, x=col, ax=axes[i], palette=color)
        axes[i].set_title(f'Box Plot of {col}')
    plt.tight_layout()
    # Display the plot
    st.pyplot(fig)

df = pd.read_csv('updated_data.csv')
numerical_features = [value for value in df.columns if df[value].dtype != 'object']
if selected == "Visualization":
    st.title('Visualization Page')
    st.subheader('Distribution of target feature')
    percentage = 100 * df['risk_of_CHD'].value_counts(normalize=True)
    plt.figure(figsize=(12, 10))
    labels = ["No risk of CHD", "Risk of CHD"]
    explode = (0, 0.1)
    colors = ['seagreen', 'indianred']
    plt.pie(percentage, labels=labels, startangle=90,
            autopct='%1.2f%%', explode=explode, shadow=True, colors=colors)
    st.pyplot()
    st.markdown('#### Insights')
    st.markdown('We can see that 86 out of 100 individuals have no risk for Coronary Heart Disease, indicating that the sample is skewed.')
    st.markdown("---")

    if st.subheader("Data distribution of numerical features for Risk of CHD true"):
        plt.figure(figsize=(16, 10))
        risk_data = df[df['risk_of_CHD'] == 'Yes']
        num_cols = 3
        num_rows = (len(numerical_features) - 1) // num_cols + 1
        for i, feature in enumerate(numerical_features):
            plt.subplot(num_rows, num_cols, i + 1)
            sns.histplot(data=risk_data, x=feature, bins=5, color='cornflowerblue', kde=True)
        plt.xlabel(feature)
        plt.tight_layout()
        # Display the plot using Streamlit's pyplot API
        st.pyplot()
        st.set_option('deprecation.showPyplotGlobalUse',
                      False)  # This line is to suppress the warning about deprecated usage
        st.markdown('#### Insights')
        st.markdown('''
    * **`Age column`:** People aged 51 and above have a higher chance of cardiovascular disease compared to all other age groups.
    * **`Heart rate`:** Individuals with a heart rate in the range of 70-81 have a higher chance of CHD compared to all other heart rate categories.
    * **`Glucose`:** People with glucose levels in the range of 73-84 have a higher chance of CHD compared to all other glucose level categories.
    * **`Cholesterol`:** Individuals with cholesterol levels ranging from 212-300 have a higher chance of CHD compared to other cholesterol categories.
    * **`BMI`:** People with a body mass index (BMI) in the range of 24-31 have a higher chance of CHD compared to other BMI categories.
    ''')

        st.subheader('Distribution of Gender')
        plt.figure(figsize=(10, 8))
        labels = ["Male", "Female"]
        colors = sns.color_palette("flare", 5)
        explode = [0.1, 0.1]
        plt.pie(risk_data["sex"].value_counts(), autopct="%1.0f%%", startangle=60, labels=labels,
                wedgeprops={"linewidth": 2, "edgecolor": "k"}, explode=explode, shadow=True,
                colors=colors)
        st.pyplot()
        st.markdown('#### Insights')
        st.markdown('Compared to females, males are having more chance of having CHD over all other independent features.')

        if st.subheader("Countplots using DASH and PLOTLY"):
            columns = ['sex', 'age', 'education', 'currentSmoker',
                       'BP_medication', 'prevalentStroke', 'prevalentHyp', 'diabetes', 'total_cholestrol',
                       'BMI',
                       'heart_rate',
                       'glucose', 'risk_of_CHD']
        selected_column = st.selectbox("Select Column:", options=columns, index=columns.index("sex"))


        def grouped_distribution(col_name):
            return px.histogram(data_frame=df,
                                x=col_name,
                                color="risk_of_CHD",
                                opacity=0.9,
                                orientation="v",
                                barmode='group',
                                width=800, height=600)


        fig = grouped_distribution(selected_column)
        st.plotly_chart(fig)
    if st.subheader("Feature Scaling & Encoding"):
        st.markdown('')
        X = df.drop('risk_of_CHD', axis=1)
        Y = df['risk_of_CHD']
        X['sex'].replace({'Male': 1, 'Female': 0}, inplace=True)
        X['currentSmoker'].replace({'Yes': 1, 'No': 0}, inplace=True)
        X['BP_medication'].replace({'Yes': 1, 'No': 0}, inplace=True)
        X['prevalentStroke'].replace({'Yes': 1, 'No': 0}, inplace=True)
        X['prevalentHyp'].replace({'Yes': 1, 'No': 0}, inplace=True)
        X['diabetes'].replace({'Yes': 1, 'No': 0}, inplace=True)
        Y.replace({'Yes': 1, 'No': 0}, inplace=True)
        scaler = MinMaxScaler()
        X[numerical_features] = scaler.fit_transform(X[numerical_features])
        st.write("Processed Data:", X.head())
        st.markdown('''
        We have used **MinMaxScaler** for the numerical features.\n
        We have used **label encoding**  for categorical features and **one-hot encoding** for education as it is of different levels.
        ''')
        if st.subheader("Heatmap"):
            plt.figure(figsize=(15, 8))
            sns.heatmap(X.corr(), annot=True, cmap='Reds')
            plt.title("Correlation Heatmap")
            plt.xlabel("Features")
            plt.ylabel("Features")
            st.pyplot()
            st.markdown('''
    - Here, we can observe a correlation between `currentSmoker` and `cigarettes_per_day`.
    - There is also a correlation between `prevalentHyp` and `MAP` (Mean Arterial Pressure).
    ''')

if selected == "Prediction":
    pickle_in = open("model.pkl", "rb")
    classifier = pickle.load(pickle_in)


    def predict_note_authentication(age, cigerettes_per_day, total_cholestrol, BMI, heart_rate, glucose, MAP,
                                    education2, education3, education4):
        value = ''

        age = age / max(df['age'])
        cigerettes_per_day = cigerettes_per_day / max(df['cigarettes_per_day'])
        total_cholestrol = total_cholestrol / max(df['total_cholestrol'])
        BMI = BMI / max(df['BMI'])
        heart_rate = heart_rate / max(data['heart_rate'])
        glucose = glucose / max(df['glucose'])
        MAP = MAP / max(df['MAP'])

        prediction = classifier.predict([[age, cigerettes_per_day, total_cholestrol, BMI, heart_rate, glucose, MAP,
                                          education2, education3, education4]])
        if prediction == 0:
            value = 'No Risk for Coronary Artery Disease'
        else:
            value = 'Risk for Coronary Artery Disease'
        return value


    def main():
        html_temp = """
    <div style="background-color: tomato; padding: 25px; border-radius: 10px;">
        <h1 style="color: white; text-align: center; font-family: Arial, sans-serif;">Risk for Coronary Heart Disease Prediction</h1>
        <p style="color: white; text-align: center; font-family: Arial, sans-serif;">Detect Risk for CHD using Machine Learning</p>
    </div>
    """
        st.markdown(html_temp, unsafe_allow_html=True)
        age = st.number_input("Age", min_value=10, max_value=100, value=None)
        cigerates = st.number_input("Cigerettes_per_day", min_value=0, max_value=100, value=None)
        cholestrol = st.number_input("Total_cholestrol", min_value=100, max_value=250, value=None)
        BMI = st.number_input("Body Mass Index", min_value=10, max_value=80, value=None)
        heart_rate = st.number_input("Heart rate", min_value=40, max_value=150, value=None)
        glucose = st.number_input("Glucose", min_value=50, max_value=150, value=None)
        MAP = st.number_input("Mean Artial Pressure", min_value=50, max_value=100, value=None)
        education2 = st.number_input("High School", min_value=0, max_value=1, value=None)
        education3 = st.number_input("Bachelors", min_value=0, max_value=1, value=None)
        education4 = st.number_input("Masters", min_value=0, max_value=1, value=None)
        result = ""
        if st.button("Predict"):
            try:
                result = predict_note_authentication(age, cigerates, cholestrol, BMI, heart_rate, glucose, MAP,
                                                     education2, education3, education4)
                if result == 1:
                    st.error('Machine Learning model predicts there is {}'.format(result))
                else:
                    st.success('Machine Learning model predicts there is {}'.format(result))
            except ValueError:
                st.warning('Sorry, the inputs you entered are not correct, Please enter again')

        if st.button("About"):
            st.text("Caronary Heart disease prediction using Machine Learning")
            st.text("Built with Streamlit")


    if __name__ == '__main__':
        main()
